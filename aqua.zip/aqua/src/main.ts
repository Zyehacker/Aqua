import { invoke } from "@tauri-apps/api/core";
import { listen } from "@tauri-apps/api/event";

type RemoteVersion = { id: string; type?: string; url?: string };
type FabricLoader = { version: string; stable: boolean };
type ModResult = {
  id: string;
  slug: string;
  title: string;
  description: string;
  icon_url?: string | null;
  downloads: number;
  project_type: string;
  game_versions: string[];
  loaders: string[];
  page_url: string;
};
type LocalItem = { name: string; path: string; size: number };
type AccountState = {
  loggedIn: boolean;
  username: string;
  uuid?: string;
  activeUuid?: string;
  accounts?: any[];
  needsRefresh?: boolean;
};

const root = document.getElementById("app");
if (!root) throw new Error("Missing #app element");

const SFX = {
  click: "/sfx/click.ogg",
  whoosh: "/sfx/whoosh.ogg",
  success: "/sfx/success.ogg",
  error: "/sfx/error.ogg",
};

function play(name: keyof typeof SFX, volume = 0.45) {
  try {
    const audio = new Audio(SFX[name]);
    audio.volume = volume;
    audio.play().catch(() => {});
  } catch {}
}

function openExternal(url: string) {
  play("click", 0.25);
  window.open(url, "_blank", "noopener,noreferrer");
}

function esc(value: unknown) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

function pct(done: number, total: number) {
  if (!total) return 0;
  return clamp(Math.round((done / total) * 100), 0, 100);
}

function recommendedArgs() {
  const cores = navigator.hardwareConcurrency || 4;
  const mem = (navigator as any).deviceMemory || 8;
  const base = Math.max(2048, Math.min(8192, Math.round(mem * 1024 * 0.65)));
  const xmx = cores >= 8 ? Math.min(12288, base + 1024) : base;

  return [
    "-XX:+UseG1GC",
    "-XX:+ParallelRefProcEnabled",
    "-XX:+UnlockExperimentalVMOptions",
    "-XX:+UseStringDeduplication",
    "-XX:MaxGCPauseMillis=50",
    "-XX:G1NewSizePercent=20",
    "-XX:G1ReservePercent=20",
    "-XX:InitiatingHeapOccupancyPercent=15",
    `-Xmx${xmx}M`,
  ].join(" ");
}

const state = {
  tab: "home",
  account: { loggedIn: false, username: "Guest" } as AccountState,
  settings: {} as any,
  versions: [] as RemoteVersion[],
  fabricLoaders: [] as FabricLoader[],
  mods: [] as ModResult[],
  localItems: [] as LocalItem[],
  targetVersion: "",
  installLoader: "vanilla",
  fabricLoaderVersion: "",
  modCategory: "mods",
  modQuery: "",
  running: false,
  installed: false,
  installing: false,
  installMessage: "Ready",
  installPct: 0,
  launchMessage: "Idle",
  launchPct: 0,
  logs: [] as string[],
  devUnlocked: localStorage.getItem("aqua_dev_unlocked") === "1",
};

async function loadSettings() {
  try {
    state.settings = await invoke("get_settings");
  } catch {
    state.settings = {};
  }

  state.targetVersion =
    state.settings?.base_mc_version ||
    state.settings?.version ||
    state.targetVersion ||
    "";

  if (!state.settings?.jvm_args?.trim()) {
    state.settings.jvm_args = recommendedArgs();
  }
}

async function saveSettings() {
  await invoke("save_settings", { settings: state.settings });
}

async function loadVersions() {
  try {
    const list = await invoke<RemoteVersion[]>("list_remote_versions", {
      includeSnapshots: false,
    });
    state.versions = Array.isArray(list) ? list : [];
    if (!state.targetVersion && state.versions.length) {
      state.targetVersion = state.versions[0].id;
      state.settings.base_mc_version = state.targetVersion;
    }
  } catch {
    state.versions = [];
  }
}

async function loadFabricLoaders() {
  if (!state.targetVersion) return;
  try {
    const list = await invoke<FabricLoader[]>("list_fabric_loaders", {
      mcVersion: state.targetVersion,
    });
    state.fabricLoaders = Array.isArray(list) ? list : [];
    const stable = state.fabricLoaders.find((x) => x.stable);
    state.fabricLoaderVersion = stable?.version || state.fabricLoaders[0]?.version || "";
  } catch {
    state.fabricLoaders = [];
    state.fabricLoaderVersion = "";
  }
}

async function refreshAuth() {
  try {
    const account = await invoke<any>("get_account");
    if (account && (account.loggedIn || account.username)) {
      state.account = {
        loggedIn: !!account.loggedIn,
        username: account.username || account.name || "Guest",
        uuid: account.uuid,
        activeUuid: account.activeUuid,
        accounts: account.accounts,
        needsRefresh: account.needsRefresh,
      };
    } else {
      state.account = { loggedIn: false, username: "Guest" };
    }
  } catch {
    state.account = { loggedIn: false, username: "Guest" };
  }
}

async function refreshInstallState() {
  try {
    const res = await invoke<any>("is_version_installed", {
      mcVersion: state.settings?.version || state.targetVersion,
      mcDir: state.settings?.mc_dir ?? null,
    });
    state.installed = !!res?.installed;
  } catch {
    state.installed = false;
  }
}

async function refreshLocalItems() {
  try {
    const items = await invoke<LocalItem[]>("list_instance_items", {
      mcVersion: state.targetVersion || state.settings?.version || "",
      category: state.modCategory,
      mcDir: state.settings?.mc_dir ?? null,
    });
    state.localItems = Array.isArray(items) ? items : [];
  } catch {
    state.localItems = [];
  }
}

async function searchMods() {
  try {
    const results = await invoke<ModResult[]>("search_modrinth", {
      query: state.modQuery,
      category: state.modCategory,
      mcVersion: state.targetVersion || state.settings?.version || "",
      loader: state.installLoader === "fabric" ? "fabric" : "vanilla",
      limit: 24,
    });
    state.mods = Array.isArray(results) ? results : [];
    play("whoosh", 0.25);
  } catch {
    state.mods = [];
  }
  await refreshLocalItems();
}

function progressCard(title: string, message: string, value: number, animated = false) {
  return `
    <div class="progress-card">
      <div class="progress-head">
        <span>${esc(title)}</span>
        <span class="muted">${esc(message)}</span>
      </div>
      <div class="progress-bar ${animated ? "animated" : ""}">
        <div class="progress-fill" style="width:${value}%"></div>
      </div>
    </div>
  `;
}

function topHeader() {
  const loggedIn = !!state.account?.loggedIn;
  const name = state.account?.username || "Guest";

  return `
    <div class="top-header">
      <div class="account-chip ${loggedIn ? "on" : "off"}">
        <div class="avatar">${esc(name.slice(0, 1).toUpperCase())}</div>
        <div class="account-meta">
          <span class="label">${loggedIn ? "Logged in" : "Not logged in"}</span>
          <strong>${esc(name)}</strong>
        </div>
      </div>

      <div class="header-stats">
        
      </div>
    </div>
  `;
}

function instanceCard() {
  return `
    <button class="instance-card" data-action="cycle-version">
      <div class="instance-card-left">
        <div class="instance-icon">▣</div>
        <div class="instance-copy">
          <strong>${esc(state.settings?.version || state.targetVersion || "No Instance Selected")}</strong>
          <span>${state.settings?.version ? "Create or select an instance" : "Create or select an instance"}</span>
        </div>
      </div>
      <div class="instance-arrow">⌄</div>
    </button>
  `;
}

function renderHome() {
  return `
    <section class="home-stage">
      <div class="home-overlay"></div>

      <div class="home-center">
        ${instanceCard()}

        <button class="play-btn" data-action="launch" ${state.running ? "disabled" : ""}>
          ${state.running ? "LAUNCHING..." : "▶ PLAY"}
        </button>

        <div class="mode-row">
          <button class="mode-chip active">— Mods</button>
          <button class="mode-chip">— Worlds</button>
          <button class="mode-chip">— Packs</button>
          <button class="mode-chip">— Shaders</button>
        </div>

        <div class="quick-row">
          <button class="quick-btn" data-action="open-mod-browser">◌ Browse Mods</button>
          <button class="quick-btn" data-action="open-worlds">⌂ Open Worlds</button>
          <button class="quick-btn" data-action="screenshots">▣ Screenshots</button>
          <button class="quick-btn secondary" data-action="install">
            ${state.installing ? "Installing..." : "+ New Instance"}
          </button>
        </div>

        <div class="search-row home-search">
          <input data-bind="instanceQuery" value="${esc(state.modQuery)}" placeholder="Search instances..." />
          <button class="search-btn" data-action="search-mods">Search</button>
          <button class="new-instance-btn" data-action="install">+ New Instance</button>
        </div>
      </div>

      <div class="home-bottom">
        ${progressCard("Install", state.installMessage, state.installPct, state.installing)}
        ${progressCard("Launch", state.launchMessage, state.launchPct, state.running)}
      </div>
    </section>
  `;
}

function renderVersions() {
  return `
    <section class="page-card">
      <div class="page-head">
        <div>
          <div class="eyebrow">My Versions</div>
          <h2>Manage Minecraft versions</h2>
        </div>
        <button class="btn" data-action="install">${state.installing ? "Installing..." : "Install / Repair"}</button>
      </div>

      <div class="form-grid">
        <label>
          Minecraft version
          <select data-bind="targetVersion">
            ${state.versions
              .map(
                (v) => `
                <option value="${esc(v.id)}" ${v.id === state.targetVersion ? "selected" : ""}>
                  ${esc(v.id)}${v.type ? ` — ${esc(v.type)}` : ""}
                </option>`
              )
              .join("")}
          </select>
        </label>

        <label>
          Loader
          <select data-bind="installLoader">
            <option value="vanilla" ${state.installLoader === "vanilla" ? "selected" : ""}>Vanilla</option>
            <option value="fabric" ${state.installLoader === "fabric" ? "selected" : ""}>Fabric</option>
          </select>
        </label>

        <label>
          Fabric loader
          <select data-bind="fabricLoaderVersion" ${state.installLoader === "fabric" ? "" : "disabled"}>
            ${state.fabricLoaders
              .map(
                (l) => `
                <option value="${esc(l.version)}" ${l.version === state.fabricLoaderVersion ? "selected" : ""}>
                  ${esc(l.version)}${l.stable ? " (stable)" : ""}
                </option>`
              )
              .join("")}
          </select>
        </label>

        <label>
          Java args
          <input data-bind="jvm_args" value="${esc(state.settings?.jvm_args || "")}" />
        </label>
      </div>

      <div class="action-row">
        <button class="btn primary" data-action="install">
          ${state.installing ? "Installing..." : "Install / Repair"}
        </button>
        <button class="btn" data-action="save-settings">Save settings</button>
        <button class="btn" data-action="optimize-args">Auto args</button>
      </div>
    </section>
  `;
}

function renderMods() {
  return `
    <section class="page-card">
      <div class="page-head">
        <div>
          <div class="eyebrow">Content</div>
          <h2>Mod browser</h2>
        </div>
        <div class="chips">
          ${[
            ["mods", "Mods"],
            ["resourcepacks", "Texture packs"],
            ["shaders", "Shaders"],
          ]
            .map(
              ([key, label]) => `
                <button class="chip ${state.modCategory === key ? "active" : ""}" data-action="category" data-value="${key}">
                  ${label}
                </button>
              `
            )
            .join("")}
        </div>
      </div>

      <div class="search-bar">
        <input data-bind="modQuery" value="${esc(state.modQuery)}" placeholder="Search Modrinth..." />
        <button class="btn primary" data-action="search-mods">Search</button>
      </div>

      <div class="split">
        <div class="list-pane">
          <div class="list-head">
            <h3>Search results</h3>
            <span class="muted">Install directly into the current instance</span>
          </div>

          <div class="result-list">
            ${
              state.mods.length
                ? state.mods
                    .map(
                      (m) => `
                        <article class="mod-card">
                          <div class="mod-info">
                            <div class="mod-title-row">
                              <strong>${esc(m.title)}</strong>
                              <span class="pill">${esc(m.project_type)}</span>
                            </div>
                            <p>${esc(m.description || "No description")}</p>
                            <div class="tiny muted">
                              ${m.downloads.toLocaleString()} downloads · ${esc(
                                (m.game_versions || []).slice(0, 4).join(", ") || "any version"
                              )}
                            </div>
                          </div>
                          <div class="mod-actions">
                            <button class="btn ghost-link" data-action="open-link" data-url="${esc(m.page_url)}">
                              Open
                            </button>
                            <button class="btn small primary" data-action="install-mod" data-project="${esc(m.id)}">
                              Install
                            </button>
                          </div>
                        </article>
                      `
                    )
                    .join("")
                : `<div class="empty-state">Search something to see results.</div>`
            }
          </div>
        </div>

        <div class="list-pane">
          <div class="list-head">
            <h3>Installed in instance</h3>
            <span class="muted">Current folder contents</span>
          </div>

          <div class="result-list">
            ${
              state.localItems.length
                ? state.localItems
                    .map(
                      (f) => `
                        <article class="mod-card local">
                          <div class="mod-info">
                            <strong>${esc(f.name)}</strong>
                            <div class="tiny muted">${Math.max(1, Math.round(f.size / 1024))} KB</div>
                          </div>
                          <div class="mod-actions">
                            <button class="btn small danger" data-action="remove-local" data-path="${esc(f.path)}">
                              Remove
                            </button>
                          </div>
                        </article>
                      `
                    )
                    .join("")
                : `<div class="empty-state">Nothing installed in this category.</div>`
            }
          </div>
        </div>
      </div>
    </section>
  `;
}

function renderSettings() {
  return `
    <section class="page-card">
      <div class="page-head">
        <div>
          <div class="eyebrow">Player</div>
          <h2>Settings</h2>
        </div>
        <button class="btn primary" data-action="save-settings">Save</button>
      </div>

      <div class="form-grid">
        <label>
          Username
          <input data-bind="username" value="${esc(state.settings?.username || "")}" />
        </label>

        <label>
          Minecraft folder
          <input data-bind="mc_dir" value="${esc(state.settings?.mc_dir || "")}" placeholder="Default if empty" />
        </label>

        <label>
          Java path
          <input data-bind="java_path" value="${esc(state.settings?.java_path || "")}" placeholder="Auto-detect if empty" />
        </label>

        <label>
          RAM (MB)
          <input data-bind="ram_mb" type="number" min="512" max="32768" value="${esc(state.settings?.ram_mb ?? 4096)}" />
        </label>
      </div>

      <div class="action-row">
        <button class="btn" data-action="optimize-args">Generate recommended args</button>
        <button class="btn" data-action="refresh-auth">Refresh account</button>
      </div>

      <div class="dev-panel ${state.devUnlocked ? "open" : ""}">
        ${
          state.devUnlocked
            ? `
              <div class="dev-head">
                <strong>Developer tools</strong>
                <span class="muted">Unlocked</span>
              </div>
              <div class="action-row">
                <button class="btn" data-action="lock-dev">Lock panel</button>
                <button class="btn" data-action="open-minecraft-folder">Open game folder</button>
              </div>
            `
            : `
              <div class="dev-lock">
                <button class="btn" data-action="unlock-dev">Unlock developer panel</button>
              </div>
            `
        }
      </div>
    </section>
  `;
}

function renderNewsRail() {
  return `
    <section class="right-panel">
      <div class="panel-top">
        <button class="small-arrow">›</button>
      </div>

      <div class="panel-tabs">
        <button class="tab active">News</button>
        <button class="tab">Discord</button>
        <button class="tab">Ko-fi</button>
        <button class="tab">News</button>
      </div>

      <div class="social-card">
        <div class="social-icon">⟡</div>
        <h3>Aqua Hub</h3>
        <p>Sign in to see friends, join clans, earn points, and chat.</p>
        <button class="sign-btn" data-action="login">
          ${state.account?.loggedIn ? "Account linked" : "Sign In"}
        </button>
        <div class="social-sub">Don't have an account? <span>Sign Up</span></div>
      </div>

      <div class="rail-links">
        <button class="rail-link" data-action="open-kofi">Support</button>
        <button class="rail-link" data-action="open-discord">Community</button>
      </div>
    </section>
  `;
}

function renderSidebar() {
  return `
    <aside class="left-sidebar">
      <div class="brand">
        <div class="brand-mark">⬟</div>
        <div class="brand-name">
          <h1>AQUA CLIENT</h1>
          <p>Aqua Client</p>
        </div>
      </div>

      <div class="nav-stack">
        <button class="nav-btn active" data-tab="home">
          <span class="nav-icon">▶</span>
          <span>Play</span>
        </button>
        <button class="nav-btn" data-tab="versions">
          <span class="nav-icon">▣</span>
          <span>My Versions</span>
        </button>

        <div class="nav-section">CONTENT</div>
        <button class="nav-btn" data-tab="mods">
          <span class="nav-icon">⬡</span>
          <span>Mods</span>
        </button>

        <div class="nav-section">EXTRAS</div>
        <button class="nav-btn" data-tab="settings">
          <span class="nav-icon">⚙</span>
          <span>Settings</span>
        </button>
        <button class="nav-btn" data-action="open-minecraft-folder">
          <span class="nav-icon">📁</span>
          <span>Game Folder</span>
        </button>
      </div>

      <div class="microsoft-card">
        <button class="microsoft-btn" data-action="login">
          <span class="win-logo">▣</span>
          <span>${state.account?.loggedIn ? "Signed in" : "Sign in with Microsoft"}</span>
        </button>
      </div>

      <div class="player-card">
        <div class="avatar large">P</div>
        <div class="player-meta">
          <strong>${esc(state.account?.username || "Player")}</strong>
          <span>${state.account?.loggedIn ? "Microsoft Account" : "Offline Mode"}</span>
        </div>
      </div>
    </aside>
  `;
}

function renderCenter() {
  return `
    <main class="center-shell">
      ${topHeader()}

      <div class="center-scroll">
        ${state.tab === "home" ? renderHome() : ""}
        ${state.tab === "versions" ? renderVersions() : ""}
        ${state.tab === "mods" ? renderMods() : ""}
        ${state.tab === "settings" ? renderSettings() : ""}
      </div>

      <div class="bottom-strip">
        <input data-bind="instanceQuery" value="${esc(state.modQuery)}" placeholder="Search instances..." />
        <button class="new-instance-btn" data-action="install">+ New Instance</button>
      </div>

      <div class="bottom-progress">
        ${progressCard("Install", state.installMessage, state.installPct, state.installing)}
        ${progressCard("Launch", state.launchMessage, state.launchPct, state.running)}
      </div>
    </main>
  `;
}

function render() {
  root.innerHTML = `
    <div class="app-shell">
      ${renderSidebar()}
      ${renderCenter()}
      ${renderNewsRail()}
    </div>
  `;
}

async function doInstall() {
  try {
    state.installing = true;
    state.installMessage = "Preparing install...";
    state.installPct = 0;
    render();
    play("click", 0.3);

    const version = await invoke<string>("install_version", {
      loader: state.installLoader,
      mcVersion: state.targetVersion,
      fabricLoaderVersion: state.installLoader === "fabric" ? state.fabricLoaderVersion || null : null,
      mcDir: state.settings?.mc_dir ?? null,
    });

    state.settings.version = version;
    state.settings.base_mc_version = state.targetVersion;
    await saveSettings();
    await refreshInstallState();

    state.installMessage = "Done";
    state.installPct = 100;
    state.installing = false;
    play("success", 0.3);
    render();
  } catch (e: any) {
    state.installing = false;
    state.installMessage = e?.toString?.() || "Install failed";
    play("error", 0.3);
    render();
  }
}

async function doLaunch() {
  try {
    state.launchMessage = "Resolving...";
    state.launchPct = 5;
    state.running = true;
    render();
    play("click", 0.25);

    await invoke("launch_minecraft", {
      settings: state.settings,
    });
  } catch (e: any) {
    state.running = false;
    state.launchMessage = e?.toString?.() || "Launch failed";
    play("error", 0.3);
    render();
  }
}

async function doLogin() {
  try {
    play("click", 0.3);
    await invoke("msa_login");
    await refreshAuth();
    play("success", 0.3);
    render();
  } catch (e: any) {
    state.logs.push(String(e?.toString?.() || e));
    play("error", 0.3);
    render();
  }
}

async function doLogout() {
  try {
    await invoke("msa_logout");
    await refreshAuth();
    play("success", 0.3);
    render();
  } catch {}
}

async function optimizeArgs() {
  state.settings.jvm_args = recommendedArgs();
  state.settings.ram_mb = Math.max(
    2048,
    Math.min(8192, Math.round((((navigator as any).deviceMemory || 8) * 1024) * 0.65))
  );
  await saveSettings();
  play("success", 0.25);
  render();
}

function unlockDevPanel() {
  const code = prompt("Enter developer code:");
  if (!code) return;

  if (code.trim() === "AQUA-DEV") {
    state.devUnlocked = true;
    localStorage.setItem("aqua_dev_unlocked", "1");
    play("success", 0.25);
    render();
  } else {
    play("error", 0.25);
    alert("Invalid developer code.");
  }
}

function lockDevPanel() {
  state.devUnlocked = false;
  localStorage.removeItem("aqua_dev_unlocked");
  play("click", 0.25);
  render();
}

function openGameFolder() {
  const path = state.settings?.mc_dir;
  if (!path) {
    alert("No Minecraft folder set.");
    return;
  }
  openExternal(`file://${path}`);
}

function bind() {
  root.onclick = async (ev) => {
    const el = (ev.target as HTMLElement).closest<HTMLElement>("[data-action], [data-tab]");
    if (!el) return;

    const tab = el.dataset.tab;
    const action = el.dataset.action;

    if (tab) {
      state.tab = tab;
      play("whoosh", 0.2);
      render();
      if (tab === "versions") await loadFabricLoaders();
      if (tab === "mods") await refreshLocalItems();
      return;
    }

    if (!action) return;

    switch (action) {
      case "login":
        await doLogin();
        break;
      case "logout":
        await doLogout();
        break;
      case "install":
        await doInstall();
        break;
      case "launch":
        await doLaunch();
        break;
      case "save-settings":
        await saveSettings();
        await refreshInstallState();
        play("success", 0.25);
        render();
        break;
      case "optimize-args":
        await optimizeArgs();
        break;
      case "search-mods":
        await searchMods();
        render();
        break;
      case "refresh-local":
        await refreshLocalItems();
        render();
        break;
      case "open-kofi":
        openExternal("https://ko-fi.com/Zyehacker");
        break;
      case "open-discord":
        openExternal("https://discord.gg/aeavxn8BAe");
        break;
      case "open-link":
        openExternal(el.dataset.url || "https://modrinth.com");
        break;
      case "install-mod":
        try {
          play("click", 0.3);
          await invoke("install_modrinth_project", {
            projectId: el.dataset.project,
            category: state.modCategory,
            mcVersion: state.targetVersion,
            loader: state.installLoader === "fabric" ? "fabric" : "vanilla",
            mcDir: state.settings?.mc_dir ?? null,
          });
          play("success", 0.3);
          await refreshLocalItems();
          render();
        } catch (e: any) {
          state.logs.push(String(e?.toString?.() || e));
          play("error", 0.3);
          render();
        }
        break;
      case "remove-local":
        try {
          await invoke("remove_instance_item", { path: el.dataset.path });
          play("success", 0.25);
          await refreshLocalItems();
          render();
        } catch {
          play("error", 0.25);
        }
        break;
      case "category":
        state.modCategory = el.dataset.value || "mods";
        await refreshLocalItems();
        play("whoosh", 0.2);
        render();
        break;
      case "unlock-dev":
        unlockDevPanel();
        break;
      case "lock-dev":
        lockDevPanel();
        break;
      case "refresh-auth":
        await refreshAuth();
        render();
        break;
      case "open-minecraft-folder":
        openGameFolder();
        break;
      case "cycle-version":
        if (state.versions.length) {
          const current = state.settings?.version || state.targetVersion;
          const idx = Math.max(0, state.versions.findIndex((v) => v.id === current));
          const next = state.versions[(idx + 1) % state.versions.length];
          state.targetVersion = next.id;
          state.settings.base_mc_version = next.id;
          await loadFabricLoaders();
          await refreshInstallState();
          render();
        }
        break;
      case "open-mod-browser":
        state.tab = "mods";
        render();
        break;
      case "open-worlds":
        alert("World browser can be added next.");
        break;
      case "screenshots":
        alert("Screenshots tab can be added next.");
        break;
    }
  };

  root.oninput = (ev) => {
    const el = ev.target as HTMLInputElement;
    const key = el.dataset.bind;
    if (!key) return;

    if (key === "ram_mb") {
      state.settings[key] = Number(el.value || 0);
    } else {
      state.settings[key] = el.value;
    }
  };

  root.onchange = async (ev) => {
    const el = ev.target as HTMLSelectElement;
    const key = el.dataset.bind;
    if (!key) return;

    if (key === "targetVersion") {
      state.targetVersion = el.value;
      state.settings.base_mc_version = el.value;
      await loadFabricLoaders();
      await refreshInstallState();
      render();
      return;
    }

    if (key === "installLoader") {
      state.installLoader = el.value;
      if (state.installLoader === "fabric") await loadFabricLoaders();
      render();
      return;
    }

    if (key === "fabricLoaderVersion") {
      state.fabricLoaderVersion = el.value;
      render();
      return;
    }

    state.settings[key] = el.value;
  };
}

async function bootstrap() {
  await loadVersions();
  await loadSettings();
  await refreshAuth();
  await refreshInstallState();
  await refreshLocalItems();

  await listen<any>("install-status", (event) => {
    const p = event.payload || {};
    state.installMessage = p.message || "Installing...";
    state.installPct = p.total
      ? pct(Number(p.done || 0), Number(p.total || 0))
      : p.phase === "done"
        ? 100
        : state.installPct;
    state.installing = p.phase !== "done" && p.phase !== "error";
    if (p.phase === "done") play("success", 0.25);
    if (p.phase === "error") play("error", 0.25);
    render();
  });

  await listen<any>("launch-status", (event) => {
    const p = event.payload || {};
    state.launchMessage = p.message || "Launching...";
    if (p.phase === "starting") state.launchPct = 10;
    if (p.phase === "running") state.launchPct = 100;
    if (p.phase === "exited" || p.phase === "error") state.running = false;
    render();
  });

  await listen<any>("launch-log", (event) => {
    const p = event.payload || {};
    if (p.line) {
      state.logs.push(String(p.line));
      if (state.logs.length > 80) state.logs.shift();
      render();
    }
  });

  render();
  bind();
}

bootstrap();
