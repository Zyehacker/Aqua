
import { invoke } from "@tauri-apps/api/core";
import { listen } from "@tauri-apps/api/event";

type RemoteVersion = { id: string; type?: string; url?: string };
type FabricLoader = { version: string; stable: boolean };
type ModResult = {
  id: string;
  slug: string;
  title: string;
  description: string;
  icon_url?: string | null;
  downloads: number;
  project_type: string;
  game_versions: string[];
  loaders: string[];
  page_url: string;
};
type LocalItem = { name: string; path: string; size: number };
type AccountState = {
  loggedIn: boolean;
  username: string;
  uuid?: string;
  activeUuid?: string;
  accounts?: any[];
  needsRefresh?: boolean;
};

type TabName = "home" | "versions" | "mods" | "settings";

const root = document.getElementById("app");
if (!root) throw new Error("Missing #app element");

document.title = "Aqua Client";

let audioCtx: AudioContext | null = null;

function ctx() {
  if (!audioCtx) {
    audioCtx = new AudioContext();
  }
  return audioCtx;
}

function tone(
  frequency: number,
  duration: number,
  type: OscillatorType = "sine",
  gainLevel = 0.04,
  endFrequency?: number,
) {
  const c = ctx();
  const osc = c.createOscillator();
  const gain = c.createGain();

  osc.type = type;
  osc.frequency.setValueAtTime(frequency, c.currentTime);
  if (endFrequency !== undefined) {
    osc.frequency.exponentialRampToValueAtTime(Math.max(20, endFrequency), c.currentTime + duration);
  }

  gain.gain.setValueAtTime(0.0001, c.currentTime);
  gain.gain.exponentialRampToValueAtTime(gainLevel, c.currentTime + 0.01);
  gain.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + duration);

  osc.connect(gain);
  gain.connect(c.destination);
  osc.start();
  osc.stop(c.currentTime + duration + 0.02);
}

function play(kind: "click" | "whoosh" | "success" | "error", volume = 1) {
  const v = Math.max(0.01, Math.min(1, volume));

  try {
    void ctx().resume();
    if (kind === "click") {
      tone(880, 0.04, "square", 0.035 * v, 720);
    } else if (kind === "whoosh") {
      tone(220, 0.12, "sine", 0.03 * v, 520);
    } else if (kind === "success") {
      tone(740, 0.05, "triangle", 0.035 * v, 980);
      setTimeout(() => tone(980, 0.06, "triangle", 0.025 * v, 1280), 60);
    } else if (kind === "error") {
      tone(190, 0.16, "sawtooth", 0.03 * v, 120);
    }
  } catch {
    // no-op
  }
}

function openExternal(url: string) {
  play("click", 0.7);
  window.open(url, "_blank", "noopener,noreferrer");
}

function esc(value: unknown) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

function pct(done: number, total: number) {
  if (!total) return 0;
  return clamp(Math.round((done / total) * 100), 0, 100);
}

function formatBytes(bytes: number) {
  if (!Number.isFinite(bytes) || bytes <= 0) return "0 KB";
  const kb = bytes / 1024;
  if (kb < 1024) return `${Math.round(kb)} KB`;
  return `${(kb / 1024).toFixed(1)} MB`;
}

function projectTypeLabel(type: string) {
  const key = type?.toLowerCase?.() || "";
  if (key === "mod") return "Mod";
  if (key === "resourcepack") return "Texture Pack";
  if (key === "shader") return "Shader";
  if (key === "modpack") return "Modpack";
  return type || "Project";
}

function recommendedArgs() {
  const cores = navigator.hardwareConcurrency || 4;
  const mem = (navigator as any).deviceMemory || 8;
  const base = Math.max(2048, Math.min(8192, Math.round(mem * 1024 * 0.65)));
  const xmx = cores >= 8 ? Math.min(12288, base + 1024) : base;

  return [
    "-XX:+UseG1GC",
    "-XX:+ParallelRefProcEnabled",
    "-XX:+UnlockExperimentalVMOptions",
    "-XX:+UseStringDeduplication",
    "-XX:MaxGCPauseMillis=50",
    "-XX:G1NewSizePercent=20",
    "-XX:G1ReservePercent=20",
    "-XX:InitiatingHeapOccupancyPercent=15",
    `-Xmx${xmx}M`,
  ].join(" ");
}

const state = {
  tab: "home" as TabName,
  account: { loggedIn: false, username: "Guest" } as AccountState,
  settings: {} as any,
  versions: [] as RemoteVersion[],
  fabricLoaders: [] as FabricLoader[],
  mods: [] as ModResult[],
  localItems: [] as LocalItem[],
  targetVersion: "",
  installLoader: "vanilla",
  fabricLoaderVersion: "",
  modCategory: "mods",
  modQuery: "",
  running: false,
  installed: false,
  installing: false,
  installMessage: "Ready",
  installPct: 0,
  launchMessage: "Idle",
  launchPct: 0,
  logs: [] as string[],
  devUnlocked: localStorage.getItem("aqua_dev_unlocked") === "1",
};

function activeVersion() {
  return state.settings?.version || state.targetVersion || state.versions[0]?.id || "";
}

function activeLoaderLabel() {
  if (state.installLoader === "fabric") {
    return state.fabricLoaderVersion ? `Fabric ${state.fabricLoaderVersion}` : "Fabric";
  }
  return "Vanilla";
}

async function loadSettings() {
  try {
    state.settings = await invoke("get_settings");
  } catch {
    state.settings = {};
  }

  state.targetVersion =
    state.settings?.base_mc_version ||
    state.settings?.version ||
    state.targetVersion ||
    "";

  if (!state.settings?.jvm_args?.trim()) {
    state.settings.jvm_args = recommendedArgs();
  }
}

async function saveSettings() {
  await invoke("save_settings", { settings: state.settings });
}

async function loadVersions() {
  try {
    const list = await invoke<RemoteVersion[]>("list_remote_versions", {
      includeSnapshots: false,
    });
    state.versions = Array.isArray(list) ? list : [];
    if (!state.targetVersion && state.versions.length) {
      state.targetVersion = state.versions[0].id;
      state.settings.base_mc_version = state.targetVersion;
    }
  } catch {
    state.versions = [];
  }
}

async function loadFabricLoaders() {
  if (!state.targetVersion) return;
  try {
    const list = await invoke<FabricLoader[]>("list_fabric_loaders", {
      mcVersion: state.targetVersion,
    });
    state.fabricLoaders = Array.isArray(list) ? list : [];
    const stable = state.fabricLoaders.find((x) => x.stable);
    state.fabricLoaderVersion = stable?.version || state.fabricLoaders[0]?.version || "";
  } catch {
    state.fabricLoaders = [];
    state.fabricLoaderVersion = "";
  }
}

async function refreshAuth() {
  try {
    const account = await invoke<any>("get_account");
    if (account && (account.loggedIn || account.username)) {
      state.account = {
        loggedIn: !!account.loggedIn,
        username: account.username || account.name || "Guest",
        uuid: account.uuid,
        activeUuid: account.activeUuid,
        accounts: account.accounts,
        needsRefresh: account.needsRefresh,
      };
    } else {
      state.account = { loggedIn: false, username: "Guest" };
    }
  } catch {
    state.account = { loggedIn: false, username: "Guest" };
  }
}

async function refreshInstallState() {
  const version = activeVersion();
  if (!version) {
    state.installed = false;
    return;
  }

  try {
    const res = await invoke<any>("is_version_installed", {
      mcVersion: version,
      mcDir: state.settings?.mc_dir ?? null,
    });
    state.installed = !!res?.installed;
  } catch {
    state.installed = false;
  }
}

async function refreshLocalItems() {
  const version = activeVersion();
  if (!version) {
    state.localItems = [];
    return;
  }

  try {
    const items = await invoke<LocalItem[]>("list_instance_items", {
      mcVersion: version,
      category: state.modCategory,
      mcDir: state.settings?.mc_dir ?? null,
    });
    state.localItems = Array.isArray(items) ? items : [];
  } catch {
    state.localItems = [];
  }
}

async function searchMods() {
  try {
    const results = await invoke<ModResult[]>("search_modrinth", {
      query: state.modQuery,
      category: state.modCategory,
      mcVersion: activeVersion(),
      loader: state.installLoader === "fabric" ? "fabric" : "vanilla",
      limit: 24,
    });
    state.mods = Array.isArray(results) ? results : [];
    play("whoosh", 0.8);
  } catch {
    state.mods = [];
  }
  await refreshLocalItems();
}

function badge(text: string, tone: "neutral" | "good" | "accent" = "neutral") {
  return `<span class="badge ${tone}">${esc(text)}</span>`;
}

function progressCard(title: string, message: string, value: number, animated = false) {
  return `
    <div class="progress-card">
      <div class="progress-head">
        <span>${esc(title)}</span>
        <span class="muted">${esc(message)}</span>
      </div>
      <div class="progress-bar ${animated ? "animated" : ""}">
        <div class="progress-fill" style="width:${value}%"></div>
      </div>
    </div>
  `;
}

function renderSidebar() {
  const loggedIn = !!state.account?.loggedIn;
  const name = state.account?.username || "Guest";

  return `
    <aside class="sidebar sidebar-left">
      <div class="brand">
        <img class="brand-icon" src="/official.png" alt="Aqua" />
        <div class="brand-copy">
          <div class="brand-title">AQUA CLIENT</div>
          <div class="brand-sub">Launcher</div>
        </div>
      </div>

      <div class="section">
        <div class="section-label">Navigation</div>
        <nav class="nav">
          <button class="nav-btn ${state.tab === "home" ? "active" : ""}" data-tab="home">
            <span class="nav-ico">▶</span><span>Play</span>
          </button>
          <button class="nav-btn ${state.tab === "versions" ? "active" : ""}" data-tab="versions">
            <span class="nav-ico">▣</span><span>Versions</span>
          </button>
          <button class="nav-btn ${state.tab === "mods" ? "active" : ""}" data-tab="mods">
            <span class="nav-ico">⬡</span><span>Mods</span>
          </button>
          <button class="nav-btn ${state.tab === "settings" ? "active" : ""}" data-tab="settings">
            <span class="nav-ico">⚙</span><span>Settings</span>
          </button>
        </nav>
      </div>

      <div class="section">
        <div class="section-label">Actions</div>
        <div class="stack">
          <button class="side-button" data-action="install">
            ${state.installing ? "Installing..." : "Install / Repair"}
          </button>
          <button class="side-button ghost" data-action="login">
            ${loggedIn ? "Microsoft linked" : "Microsoft login"}
          </button>
          <button class="side-button ghost" data-action="logout" ${loggedIn ? "" : "disabled"}>
            Logout
          </button>
          <button class="side-button ghost" data-action="save-settings">Save settings</button>
        </div>
      </div>

      <div class="section account-panel">
        <div class="section-label">Account</div>
        <div class="account-card">
          <div class="avatar">${esc(name.slice(0, 1).toUpperCase())}</div>
          <div class="account-meta">
            <strong>${esc(name)}</strong>
            <span>${loggedIn ? "Microsoft account" : "Offline mode"}</span>
          </div>
        </div>
      </div>

      <div class="section">
        <div class="section-label">Storage</div>
        <div class="mini-list">
          <div class="mini-row"><span>Selected</span><strong>${esc(activeVersion() || "No version")}</strong></div>
          <div class="mini-row"><span>Loader</span><strong>${esc(activeLoaderLabel())}</strong></div>
          <div class="mini-row"><span>RAM</span><strong>${esc(state.settings?.ram_mb ?? 4096)} MB</strong></div>
        </div>
      </div>

      <div class="section footer-actions">
        <button class="link-button" data-action="open-kofi">Ko-fi</button>
        <button class="link-button" data-action="open-discord">Discord</button>
      </div>
    </aside>
  `;
}

function renderTopBar() {
  const loggedIn = !!state.account?.loggedIn;
  const name = state.account?.username || "Guest";

  return `
    <header class="topbar">
      <div class="topbar-left">
        <div>
          <div class="eyebrow">Aqua Client</div>
          <h1>${state.tab === "home" ? "Play" : state.tab === "versions" ? "Versions" : state.tab === "mods" ? "Mods" : "Settings"}</h1>
        </div>
      </div>

      <div class="topbar-right">
        <div class="chip account-chip ${loggedIn ? "on" : "off"}">
          <div class="avatar small">${esc(name.slice(0, 1).toUpperCase())}</div>
          <div class="chip-meta">
            <span>${loggedIn ? "Signed in" : "Not signed in"}</span>
            <strong>${esc(name)}</strong>
          </div>
        </div>
      </div>
    </header>
  `;
}

function renderHome() {
  return `
    <section class="home-stage">
      <div class="home-overlay"></div>
      <div class="home-stage-inner">
        <div class="hero-head">
          <div class="hero-brand">
            <img class="hero-icon" src="/official.png" alt="Aqua" />
            <div>
              <div class="eyebrow">Aqua Client</div>
              <h2>Clean launcher. Strong layout. No clutter.</h2>
            </div>
          </div>

          <div class="hero-status">
            ${badge(activeVersion() || "No version selected", "accent")}
            ${badge(activeLoaderLabel(), "neutral")}
          </div>
        </div>

        <div class="hero-main">
          <div class="hero-card">
            <div class="hero-card-top">
              <div class="hero-card-title">
                <span class="card-kicker">Selected instance</span>
                <strong>${esc(activeVersion() || "No instance selected")}</strong>
                <span class="muted">${state.installed ? "Installed and ready" : "Not installed yet"}</span>
              </div>

              <div class="selector-grid">
                <label>
                  Minecraft version
                  <select data-bind="targetVersion">
                    ${state.versions
                      .map(
                        (v) => `
                          <option value="${esc(v.id)}" ${v.id === state.targetVersion ? "selected" : ""}>
                            ${esc(v.id)}${v.type ? ` — ${esc(v.type)}` : ""}
                          </option>
                        `,
                      )
                      .join("")}
                  </select>
                </label>

                <label>
                  Loader
                  <select data-bind="installLoader">
                    <option value="vanilla" ${state.installLoader === "vanilla" ? "selected" : ""}>Vanilla</option>
                    <option value="fabric" ${state.installLoader === "fabric" ? "selected" : ""}>Fabric</option>
                  </select>
                </label>

                <label>
                  Fabric loader
                  <select data-bind="fabricLoaderVersion" ${state.installLoader === "fabric" ? "" : "disabled"}>
                    ${state.fabricLoaders
                      .map(
                        (l) => `
                          <option value="${esc(l.version)}" ${l.version === state.fabricLoaderVersion ? "selected" : ""}>
                            ${esc(l.version)}${l.stable ? " (stable)" : ""}
                          </option>
                        `,
                      )
                      .join("")}
                  </select>
                </label>

                <label>
                  Java args
                  <input data-bind="jvm_args" value="${esc(state.settings?.jvm_args || "")}" />
                </label>
              </div>
            </div>

            <div class="hero-play-row">
              <button class="play-button" data-action="launch" ${state.running ? "disabled" : ""}>
                ${state.running ? "Launching..." : "Play"}
              </button>
              <button class="launch-secondary" data-action="install">
                ${state.installing ? "Installing..." : "Install / Repair"}
              </button>
            </div>

            <div class="hero-tools">
              <button class="tool-button ${state.tab === "versions" ? "active" : ""}" data-tab="versions">Versions</button>
              <button class="tool-button ${state.tab === "mods" ? "active" : ""}" data-tab="mods">Mods</button>
              <button class="tool-button ${state.tab === "settings" ? "active" : ""}" data-tab="settings">Settings</button>
              <button class="tool-button ghost" data-action="login">
                ${state.account?.loggedIn ? "Account linked" : "Login"}
              </button>
            </div>
          </div>

          <div class="home-cards">
            <div class="info-card">
              <span>Account</span>
              <strong>${esc(state.account?.username || "Guest")}</strong>
            </div>
            <div class="info-card">
              <span>Loader</span>
              <strong>${esc(activeLoaderLabel())}</strong>
            </div>
            <div class="info-card">
              <span>RAM</span>
              <strong>${esc(state.settings?.ram_mb ?? 4096)} MB</strong>
            </div>
          </div>
        </div>

        <div class="home-status">
          ${progressCard("Install", state.installMessage, state.installPct, state.installing)}
          ${progressCard("Launch", state.launchMessage, state.launchPct, state.running)}
        </div>
      </div>
    </section>
  `;
}

function renderVersions() {
  return `
    <section class="page">
      <div class="page-grid two">
        <div class="panel">
          <div class="panel-head">
            <div>
              <div class="eyebrow">Versions</div>
              <h2>Manage versions</h2>
            </div>
            <button class="panel-cta" data-action="install">${state.installing ? "Installing..." : "Install / Repair"}</button>
          </div>

          <div class="selector-grid">
            <label>
              Minecraft version
              <select data-bind="targetVersion">
                ${state.versions
                  .map(
                    (v) => `
                      <option value="${esc(v.id)}" ${v.id === state.targetVersion ? "selected" : ""}>
                        ${esc(v.id)}${v.type ? ` — ${esc(v.type)}` : ""}
                      </option>
                    `,
                  )
                  .join("")}
              </select>
            </label>

            <label>
              Loader
              <select data-bind="installLoader">
                <option value="vanilla" ${state.installLoader === "vanilla" ? "selected" : ""}>Vanilla</option>
                <option value="fabric" ${state.installLoader === "fabric" ? "selected" : ""}>Fabric</option>
              </select>
            </label>

            <label>
              Fabric loader
              <select data-bind="fabricLoaderVersion" ${state.installLoader === "fabric" ? "" : "disabled"}>
                ${state.fabricLoaders
                  .map(
                    (l) => `
                      <option value="${esc(l.version)}" ${l.version === state.fabricLoaderVersion ? "selected" : ""}>
                        ${esc(l.version)}${l.stable ? " (stable)" : ""}
                      </option>
                    `,
                  )
                  .join("")}
              </select>
            </label>

            <label>
              Java args
              <input data-bind="jvm_args" value="${esc(state.settings?.jvm_args || "")}" />
            </label>
          </div>

          <div class="inline-actions">
            <button class="panel-btn primary" data-action="install">Install / Repair</button>
            <button class="panel-btn" data-action="save-settings">Save settings</button>
            <button class="panel-btn" data-action="optimize-args">Auto args</button>
          </div>
        </div>

        <div class="panel">
          <div class="panel-head">
            <div>
              <div class="eyebrow">Status</div>
              <h2>Install overview</h2>
            </div>
          </div>

          ${progressCard("Install", state.installMessage, state.installPct, state.installing)}
          <div class="divider"></div>
          ${progressCard("Launch", state.launchMessage, state.launchPct, state.running)}
        </div>
      </div>
    </section>
  `;
}

function renderModCard(m: ModResult) {
  const gameVersions = (m.game_versions || []).slice(0, 4);
  const loaders = (m.loaders || []).slice(0, 3);

  return `
    <article class="mod-card">
      <div class="mod-icon-wrap">
        ${
          m.icon_url
            ? `<img class="mod-icon" src="${esc(m.icon_url)}" alt="${esc(m.title)}" />`
            : `<div class="mod-icon placeholder">${esc((m.title || "?").slice(0, 1).toUpperCase())}</div>`
        }
      </div>

      <div class="mod-body">
        <div class="mod-title-row">
          <strong>${esc(m.title)}</strong>
          <span class="project-badge">${esc(projectTypeLabel(m.project_type))}</span>
        </div>
        <p>${esc(m.description || "No description")}</p>
        <div class="mod-tags">
          <span class="meta">${m.downloads.toLocaleString()} downloads</span>
          ${gameVersions.map((v) => `<span class="tag">${esc(v)}</span>`).join("")}
          ${loaders.map((l) => `<span class="tag">${esc(l)}</span>`).join("")}
        </div>
      </div>

      <div class="mod-actions">
        <button class="panel-btn ghost" data-action="open-link" data-url="${esc(m.page_url)}">Open</button>
        <button class="panel-btn primary" data-action="install-mod" data-project="${esc(m.id)}">Install</button>
      </div>
    </article>
  `;
}

function renderMods() {
  return `
    <section class="page">
      <div class="page-grid two">
        <div class="panel">
          <div class="panel-head">
            <div>
              <div class="eyebrow">Modrinth</div>
              <h2>Browse content</h2>
            </div>

            <div class="chip-row">
              ${[
                ["mods", "Mods"],
                ["resourcepacks", "Texture Packs"],
                ["shaders", "Shaders"],
              ]
                .map(
                  ([key, label]) => `
                    <button class="chip-btn ${state.modCategory === key ? "active" : ""}" data-action="category" data-value="${key}">
                      ${label}
                    </button>
                  `,
                )
                .join("")}
            </div>
          </div>

          <div class="search-row">
            <input data-bind="modQuery" value="${esc(state.modQuery)}" placeholder="Search Modrinth..." />
            <button class="panel-btn primary" data-action="search-mods">Search</button>
          </div>

          <div class="result-stack">
            ${
              state.mods.length
                ? state.mods.map(renderModCard).join("")
                : `<div class="empty-state">Search something to see results.</div>`
            }
          </div>
        </div>

        <div class="panel">
          <div class="panel-head">
            <div>
              <div class="eyebrow">Instance</div>
              <h2>Installed items</h2>
            </div>
          </div>

          <div class="result-stack">
            ${
              state.localItems.length
                ? state.localItems
                    .map(
                      (f) => `
                        <article class="local-card">
                          <div class="local-name">
                            <strong>${esc(f.name)}</strong>
                            <span>${formatBytes(f.size)}</span>
                          </div>
                          <button class="panel-btn danger" data-action="remove-local" data-path="${esc(f.path)}">Remove</button>
                        </article>
                      `,
                    )
                    .join("")
                : `<div class="empty-state">Nothing installed in this category.</div>`
            }
          </div>
        </div>
      </div>
    </section>
  `;
}

function renderSettings() {
  return `
    <section class="page">
      <div class="page-grid one">
        <div class="panel">
          <div class="panel-head">
            <div>
              <div class="eyebrow">Player</div>
              <h2>Settings</h2>
            </div>
            <button class="panel-cta" data-action="save-settings">Save</button>
          </div>

          <div class="selector-grid">
            <label>
              Username
              <input data-bind="username" value="${esc(state.settings?.username || "")}" />
            </label>

            <label>
              Minecraft folder
              <input data-bind="mc_dir" value="${esc(state.settings?.mc_dir || "")}" placeholder="Default if empty" />
            </label>

            <label>
              Java path
              <input data-bind="java_path" value="${esc(state.settings?.java_path || "")}" placeholder="Auto-detect if empty" />
            </label>

            <label>
              RAM (MB)
              <input data-bind="ram_mb" type="number" min="512" max="32768" value="${esc(state.settings?.ram_mb ?? 4096)}" />
            </label>

            <label class="full">
              Java args
              <input data-bind="jvm_args" value="${esc(state.settings?.jvm_args || "")}" />
            </label>
          </div>

          <div class="inline-actions">
            <button class="panel-btn" data-action="optimize-args">Generate recommended args</button>
            <button class="panel-btn" data-action="refresh-auth">Refresh account</button>
            <button class="panel-btn ghost" data-action="logout" ${state.account?.loggedIn ? "" : "disabled"}>Logout</button>
          </div>

          <div class="dev-shell">
            ${
              state.devUnlocked
                ? `
                  <div class="dev-head">
                    <strong>Developer tools</strong>
                    <span class="muted">Unlocked</span>
                  </div>
                  <div class="inline-actions">
                    <button class="panel-btn" data-action="lock-dev">Lock panel</button>
                  </div>
                `
                : `
                  <div class="dev-lock">
                    <button class="panel-btn" data-action="unlock-dev">Unlock developer panel</button>
                    <span class="muted">Developer-only controls live here.</span>
                  </div>
                `
            }
          </div>
        </div>
      </div>
    </section>
  `;
}

function renderNewsRail() {
  return `
    <aside class="sidebar sidebar-right">
      <div class="section">
        <div class="section-label">News</div>
        <div class="news-card">
          <div class="news-head">
            <strong>News</strong>
            <span class="muted">No news yet</span>
          </div>
          <div class="news-empty">
            Developers can wire posts here later.
          </div>
        </div>
      </div>

      <div class="section">
        <div class="section-label">Community</div>
        <div class="community-card">
          <p>Use these links for support, updates, and community access.</p>
          <button class="link-button full" data-action="open-discord">Discord</button>
          <button class="link-button full" data-action="open-kofi">Ko-fi</button>
        </div>
      </div>

      <div class="section">
        <div class="section-label">Launcher info</div>
        <div class="mini-list">
          <div class="mini-row"><span>Instance</span><strong>${esc(activeVersion() || "No version")}</strong></div>
          <div class="mini-row"><span>Loader</span><strong>${esc(activeLoaderLabel())}</strong></div>
          <div class="mini-row"><span>Account</span><strong>${esc(state.account?.username || "Guest")}</strong></div>
        </div>
      </div>

      <div class="section">
        ${progressCard("Install", state.installMessage, state.installPct, state.installing)}
      </div>
    </aside>
  `;
}

function renderCenter() {
  return `
    <main class="center-shell">
      ${renderTopBar()}

      <div class="center-scroll">
        ${state.tab === "home" ? renderHome() : ""}
        ${state.tab === "versions" ? renderVersions() : ""}
        ${state.tab === "mods" ? renderMods() : ""}
        ${state.tab === "settings" ? renderSettings() : ""}
      </div>
    </main>
  `;
}

function render() {
  root.innerHTML = `
    <div class="app-shell">
      ${renderSidebar()}
      ${renderCenter()}
      ${renderNewsRail()}
    </div>
  `;
}

async function doInstall() {
  try {
    state.installing = true;
    state.installMessage = "Preparing install...";
    state.installPct = 0;
    render();
    play("click", 0.8);

    const version = await invoke<string>("install_version", {
      loader: state.installLoader,
      mcVersion: activeVersion(),
      fabricLoaderVersion: state.installLoader === "fabric" ? state.fabricLoaderVersion || null : null,
      mcDir: state.settings?.mc_dir ?? null,
    });

    state.settings.version = version;
    state.settings.base_mc_version = activeVersion();
    await saveSettings();
    await refreshInstallState();

    state.installMessage = "Done";
    state.installPct = 100;
    state.installing = false;
    play("success", 0.8);
    render();
  } catch (e: any) {
    state.installing = false;
    state.installMessage = e?.toString?.() || "Install failed";
    play("error", 0.8);
    render();
  }
}

async function doLaunch() {
  try {
    state.launchMessage = "Resolving Java...";
    state.launchPct = 5;
    state.running = true;
    render();
    play("click", 0.8);

    await invoke("launch_minecraft", {
      settings: state.settings,
    });
  } catch (e: any) {
    state.running = false;
    state.launchMessage = e?.toString?.() || "Launch failed";
    play("error", 0.8);
    render();
  }
}

async function doLogin() {
  try {
    play("click", 0.8);
    await invoke("msa_login");
    await refreshAuth();
    play("success", 0.8);
    render();
  } catch (e: any) {
    state.logs.push(String(e?.toString?.() || e));
    play("error", 0.8);
    render();
  }
}

async function doLogout() {
  try {
    await invoke("msa_logout");
    await refreshAuth();
    play("success", 0.8);
    render();
  } catch {
    // no-op
  }
}

async function optimizeArgs() {
  state.settings.jvm_args = recommendedArgs();
  state.settings.ram_mb = Math.max(
    2048,
    Math.min(8192, Math.round((((navigator as any).deviceMemory || 8) * 1024) * 0.65)),
  );
  await saveSettings();
  play("success", 0.8);
  render();
}

function unlockDevPanel() {
  const code = prompt("Enter developer code:");
  if (!code) return;

  if (code.trim() === "AQUA-DEV") {
    state.devUnlocked = true;
    localStorage.setItem("aqua_dev_unlocked", "1");
    play("success", 0.8);
    render();
  } else {
    play("error", 0.8);
    alert("Invalid developer code.");
  }
}

function lockDevPanel() {
  state.devUnlocked = false;
  localStorage.removeItem("aqua_dev_unlocked");
  play("click", 0.8);
  render();
}

function openGameFolder() {
  const path = state.settings?.mc_dir;
  if (!path) {
    alert("No Minecraft folder set.");
    return;
  }
  window.open(`file://${path}`, "_blank", "noopener,noreferrer");
}

function setTab(tab: TabName) {
  state.tab = tab;
  play("whoosh", 0.8);
  render();
  if (tab === "versions") void loadFabricLoaders();
  if (tab === "mods") void refreshLocalItems();
}

function bind() {
  root.addEventListener("click", async (ev) => {
    const el = (ev.target as HTMLElement).closest<HTMLElement>("[data-action],[data-tab]");
    if (!el) return;

    const tab = el.dataset.tab as TabName | undefined;
    const action = el.dataset.action;

    if (tab) {
      setTab(tab);
      return;
    }

    if (!action) return;

    switch (action) {
      case "login":
        await doLogin();
        break;
      case "logout":
        await doLogout();
        break;
      case "install":
        await doInstall();
        break;
      case "launch":
        await doLaunch();
        break;
      case "save-settings":
        await saveSettings();
        await refreshInstallState();
        play("success", 0.8);
        render();
        break;
      case "optimize-args":
        await optimizeArgs();
        break;
      case "search-mods":
        await searchMods();
        render();
        break;
      case "open-kofi":
        openExternal("https://ko-fi.com/Zyehacker");
        break;
      case "open-discord":
        openExternal("https://discord.gg/aeavxn8BAe");
        break;
      case "open-link":
        openExternal(el.dataset.url || "https://modrinth.com");
        break;
      case "install-mod":
        try {
          play("click", 0.8);
          await invoke("install_modrinth_project", {
            projectId: el.dataset.project,
            category: state.modCategory,
            mcVersion: activeVersion(),
            loader: state.installLoader === "fabric" ? "fabric" : "vanilla",
            mcDir: state.settings?.mc_dir ?? null,
          });
          play("success", 0.8);
          await refreshLocalItems();
          render();
        } catch (e: any) {
          state.logs.push(String(e?.toString?.() || e));
          play("error", 0.8);
          render();
        }
        break;
      case "remove-local":
        try {
          await invoke("remove_instance_item", { path: el.dataset.path });
          play("success", 0.8);
          await refreshLocalItems();
          render();
        } catch {
          play("error", 0.8);
        }
        break;
      case "category":
        state.modCategory = el.dataset.value || "mods";
        await refreshLocalItems();
        play("whoosh", 0.8);
        render();
        break;
      case "unlock-dev":
        unlockDevPanel();
        break;
      case "lock-dev":
        lockDevPanel();
        break;
      case "refresh-auth":
        await refreshAuth();
        render();
        break;
      case "open-minecraft-folder":
        openGameFolder();
        break;
      default:
        break;
    }
  });

  root.addEventListener("input", (ev) => {
    const el = ev.target as HTMLInputElement | HTMLSelectElement;
    const key = el.dataset.bind;
    if (!key) return;

    if (key === "ram_mb") {
      state.settings[key] = Number((el as HTMLInputElement).value || 0);
    } else {
      state.settings[key] = (el as HTMLInputElement | HTMLSelectElement).value;
    }
  });

  root.addEventListener("change", async (ev) => {
    const el = ev.target as HTMLInputElement | HTMLSelectElement;
    const key = el.dataset.bind;
    if (!key) return;

    if (key === "targetVersion") {
      state.targetVersion = el.value;
      state.settings.base_mc_version = el.value;
      await loadFabricLoaders();
      await refreshInstallState();
      render();
      return;
    }

    if (key === "installLoader") {
      state.installLoader = el.value;
      if (state.installLoader === "fabric") {
        await loadFabricLoaders();
      }
      render();
      return;
    }

    if (key === "fabricLoaderVersion") {
      state.fabricLoaderVersion = el.value;
      render();
      return;
    }

    state.settings[key] = el.value;
  });
}

async function bootstrap() {
  await loadVersions();
  await loadSettings();
  await refreshAuth();
  await refreshInstallState();
  await refreshLocalItems();

  await listen<any>("install-status", (event) => {
    const p = event.payload || {};
    state.installMessage = p.message || "Installing...";
    state.installPct = p.total
      ? pct(Number(p.done || 0), Number(p.total || 0))
      : p.phase === "done"
        ? 100
        : state.installPct;
    state.installing = p.phase !== "done" && p.phase !== "error";
    if (p.phase === "done") play("success", 0.8);
    if (p.phase === "error") play("error", 0.8);
    render();
  });

  await listen<any>("launch-status", (event) => {
    const p = event.payload || {};
    state.launchMessage = p.message || "Launching...";
    if (p.phase === "starting") state.launchPct = 10;
    if (p.phase === "running") state.launchPct = 100;
    if (p.phase === "exited" || p.phase === "error") state.running = false;
    render();
  });

  await listen<any>("launch-log", (event) => {
    const p = event.payload || {};
    if (p.line) {
      state.logs.push(String(p.line));
      if (state.logs.length > 80) state.logs.shift();
      render();
    }
  });

  render();
  bind();
}

bootstrap();
